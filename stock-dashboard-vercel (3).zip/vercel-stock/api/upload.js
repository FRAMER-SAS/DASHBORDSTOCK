const fs   = require('fs');
const path = require('path');

let _lookup = null;

function getLookup() {
  if (_lookup) return _lookup;
  try {
    const p = path.join(process.cwd(), 'data', 'lookup.json');
    _lookup = JSON.parse(fs.readFileSync(p, 'utf-8'));
  } catch (e) {
    _lookup = {};
  }
  return _lookup;
}

function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    let body = req.body;

    // Si Vercel no parseó el body, leerlo manualmente
    if (!body || typeof body === 'string') {
      try { body = JSON.parse(body); } catch(e) {
        res.status(400).json({ error: 'Body no es JSON válido' });
        return;
      }
    }

    if (!Array.isArray(body) || body.length < 3) {
      res.status(422).json({
        error: 'Se esperaba un array de artículos, se recibió: ' + typeof body
      });
      return;
    }

    const lookup = getLookup();
    const num = v => {
      const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
      return isNaN(n) ? 0 : n;
    };

    const data = body
      .map(r => {
        const cod  = String(r.codigo || '').trim();
        const info = lookup[cod] || {};
        return {
          codigo:       cod,
          descripcion:  String(r.descripcion  || '').trim(),
          medida:       String(r.medida       || 'Unidad').trim(),
          stock_actual: Math.round(num(r.stock_actual) * 100) / 100,
          pedidos:      Math.round(num(r.pedidos)      * 100) / 100,
          stock_final:  Math.round(num(r.stock_final)  * 100) / 100,
          rubro:        info.rubro     || '',
          proveedor:    info.proveedor || '',
          desc_full:    info.desc_full || '',
        };
      })
      .filter(r => r.codigo && r.codigo.length >= 3);

    res.setHeader('Cache-Control', 'no-store');
    res.status(200).json({
      ok:      true,
      count:   data.length,
      updated: new Date().toISOString(),
      data:    data,
    });

  } catch (err) {
    res.status(500).json({ error: 'Error interno: ' + err.message });
  }
}

module.exports = handler;
