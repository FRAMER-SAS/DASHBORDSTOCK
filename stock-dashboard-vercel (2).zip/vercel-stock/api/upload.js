const fs   = require('fs');
const path = require('path');

// API recibe JSON puro (el Excel ya fue parseado en el browser)
// bodyParser habilitado (default), max 4mb
module.exports.config = {
  api: { bodyParser: { sizeLimit: '4mb' } },
};

let _lookup = null;
function getLookup() {
  if (_lookup) return _lookup;
  try {
    _lookup = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'data', 'lookup.json'), 'utf-8'));
  } catch (e) {
    _lookup = {};
  }
  return _lookup;
}

module.exports = function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST')    return res.status(405).json({ error: 'Método no permitido' });

  try {
    const rows = req.body;
    if (!Array.isArray(rows) || rows.length < 3) {
      return res.status(422).json({ error: `Datos inválidos: se recibieron ${Array.isArray(rows) ? rows.length : 0} filas.` });
    }

    const lookup = getLookup();
    const num = v => { const n = parseFloat(String(v ?? '').replace(',', '.')); return isNaN(n) ? 0 : n; };

    const data = rows.map(r => {
      const cod  = String(r.codigo  || '').trim();
      const info = lookup[cod] || {};
      return {
        codigo:       cod,
        descripcion:  String(r.descripcion  || '').trim(),
        medida:       String(r.medida       || 'Unidad').trim(),
        stock_actual: Math.round(num(r.stock_actual) * 100) / 100,
        pedidos:      Math.round(num(r.pedidos)      * 100) / 100,
        stock_final:  Math.round(num(r.stock_final)  * 100) / 100,
        rubro:        info.rubro     || '',
        proveedor:    info.proveedor || '',
        desc_full:    info.desc_full || '',
      };
    }).filter(r => r.codigo && r.codigo.length >= 3);

    res.setHeader('Cache-Control', 'no-store');
    return res.status(200).json({
      ok:      true,
      count:   data.length,
      updated: new Date().toISOString(),
      data,
    });

  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno: ' + err.message });
  }
};
